import .gdgtm_core
