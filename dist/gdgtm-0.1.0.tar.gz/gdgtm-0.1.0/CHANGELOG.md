## Versions 0.0.1 - 0.0.4 (Closed)
- Developing function to downlaod data from Chelsa
- Developing the core pipeline up to post-reprojecting application of a Bounding Box

## Version 0.1
- 0.1.0: implemented two functions: download of cog names from STAC collection and downloading cogs from OLM (in test)

## Version 0.2 (planned)
- 0.2.0: implement raster mosaics
- 0.2.1: implement raster aligning

## Version 0.3 (planned)
- 0.3.0 implement raster-to-raster validation
